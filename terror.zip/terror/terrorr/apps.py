from django.apps import AppConfig


class TerrorrConfig(AppConfig):
    name = 'terrorr'
