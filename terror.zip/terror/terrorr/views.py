from django.shortcuts import render,redirect
from django.http import HttpRequest
from .models import keywords,urllist,blocklist
from .urltext import * 
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
import os
from django.contrib.admin import forms
from django.contrib import messages

def login(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method =="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        if username and password:
           user= authenticate(request,username=username,password=password)
           if not user:
                raise forms.ValidationError('This user does not exist')
           if not user.check_password(password):
                raise forms.ValidationError('Incorrect password')
           if not user.is_active:
                raise forms.ValidationError('This user is not active')
        if user is not None:
            login(request,username)
            redirect('/') 
        else:
            messages.info(request,"Username or Password is Incorrect !")
    context={}
    return render(request,'registration/login.html',context)

def logoutuser(request):
    logout(request)
    return redirect('login')

def sign_up(request):
    context = {}
    if request.user.is_authenticated:
        return redirect('home')
    form = UserCreationForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            user = form.save()
            messages.success(request,'Account created successfully !')
            return redirect('login')
    context['form']=form
    return render(request,'registration/sign_up.html',context)

@login_required(login_url='login')
def home(request):
    return render(request,'home.html')

@login_required(login_url='login')
def addkeyword(request):
    if request.method=="POST" :
        keyword=request.POST["keyword"]
        if len(keyword)!=0:
            data=keywords.objects.create(name=keyword)
            data.save()
        return render(request,'addkeyword.html')
    else:
        return render(request,'addkeyword.html')

@login_required(login_url='login')
def showkeyword(request):
    allkey=keywords.objects.all()
    return render(request,'showkeywords.html',{'allkey':allkey})

@login_required(login_url='login')
def delkey(request,key):
    keywords.objects.filter(name=key).delete()
    return redirect("/showkeyword")

@login_required(login_url='login')
def addurl(request):
    if request.method=="POST" :
        url=request.POST["url"]
        if len(url)!=0:
            data=urllist.objects.create(name=url)
            data.save()
        return redirect('/')
    else:
        return render(request,'addurl.html')

@login_required(login_url='login')
def checkwebsite(request):
   allurl=urllist.objects.all()
   allkey=keywords.objects.all()
   a=urltext()
   mykeys=[]
   for key in allkey:
       mykeys.append(key.name)
   found_key=[]
   for url in allurl:
      found_key.append(a.main(url.name,mykeys))  
   keylen=len(found_key) 
   return render(request,'showwebsites.html',{'allurl':allurl,'allkey':allkey,'keys':found_key,'keylen':keylen})

@login_required(login_url='login')
def block(request,url):
    ur=url.replace("https://","")
    urll=ur.split("/",1)[0]
    urllist.objects.filter(name__contains=urll).delete()
    blocklist.objects.create(name=url).save()
    
    with open('/etc/hosts', 'rt') as f:
     s = f.read() + '\n' + '127.0.0.1\t\t\t'+urll+'\n'
    with open('/tmp/etc_hosts.tmp', 'wt') as outf:
        outf.write(s)

    os.system('sudo mv /tmp/etc_hosts.tmp /etc/hosts')
    return redirect('/checkwebsite')

@login_required(login_url='login')
def showblockweb(request):
    blocklistt=blocklist.objects.all()
    return render(request,"showblockweb.html",{'blocklist':blocklistt})        