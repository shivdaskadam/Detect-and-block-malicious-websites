from django.urls import  path
from django.conf.urls.static import static
from django.conf import settings
from . import views

urlpatterns=[path('login',views.login,name="login"),
path('sign_up',views.sign_up,name="sign_up"),
path('logoutuser',views.logoutuser,name="logoutuser"),
path('',views.home,name="home"),
path('addkeyword',views.addkeyword,name="addkeyword"),
path('showkeyword',views.showkeyword,name="showkeyword"),
path('delkey/<str:key>',views.delkey,name="delkey"),
path('addurl',views.addurl,name="addurl"),
path('checkwebsite',views.checkwebsite,name="checkwebsite"),
path('block/<path:url>',views.block,name="block"),
path('showblockweb',views.showblockweb,name="showblockweb")

]