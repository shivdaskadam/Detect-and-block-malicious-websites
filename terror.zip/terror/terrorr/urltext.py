import urllib3
from bs4 import BeautifulSoup
import re
from multi_rake import Rake
from flashtext import KeywordProcessor

rake=Rake(
    max_words=1
)
keyword_processor = KeywordProcessor()

Newlines = re.compile(r'[\r\n]\s+')
class urltext :
    def addkeylist(self,keylist):
        for key in keylist:
            keyword_processor.add_keyword(key)

    def getPageText(self,url):
        # given a url, get page content
        https = urllib3.PoolManager()
        r = https.request('GET', url)
        data=r.data
        
        bs = BeautifulSoup(data)
        
        for s in bs.findAll('script'):
            s.replaceWith('')
        
    
        txt = bs.find('body').getText('\n')
        
        for k in bs.findAll("\\n"):
            k.replaceWith(' ')
        
        return Newlines.sub('\n', txt)

    def unique(self,list1): 
        
    
        list_set = set(list1) 
        
        unique_list = (list(list_set)) 
        return unique_list

    def main(self,urll,klist):
        keylist=klist
        url=urll
        txt = self.getPageText(url)
        text=str(txt)
        self.addkeylist(keylist)
        keywords_found = keyword_processor.extract_keywords(text)
        if not keywords_found:
            return "No keywords found"
        print(keywords_found)   
        strr=str(self.unique(keywords_found))
        print(strr)
        return strr
        #keywords=rake.apply(txt)
        #print(keywords)
