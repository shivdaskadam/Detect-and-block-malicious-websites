from django.db import models

# Create your models here.
class keywords(models.Model):
    name = models.CharField(max_length=100)

class urllist(models.Model):
    name = models.CharField(max_length=1000)

class blocklist(models.Model):
    name = models.CharField(max_length=1000)

