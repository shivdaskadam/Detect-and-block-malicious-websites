from django.contrib import admin
from .models import keywords,urllist,blocklist
# Register your models here.
admin.site.register(keywords)
admin.site.register(urllist)
admin.site.register(blocklist)
